import pandas as pd
import matplotlib.pyplot as plt
from prophet import Prophet
from sklearn.metrics import mean_absolute_error, mean_squared_error
import numpy as np
from itertools import product

# Carga y preprocesamiento del dataset
file_path = "dataset_produccion.csv"
df = pd.read_csv(file_path)

# Manejar valores nulos
df.dropna(subset=["Mes", "Año", "Producción Total (GWh)"], inplace=True) # Para produccion total (comentar linea 15)
df['Subcategoría'] = df['Subcategoría'].str.strip()  
df = df[df["Subcategoría"] == "Hidráulica"] # Para producción Hidráulica colocar ==, para producción Sin Hidráulica colocar !=

# Mapear nombres de meses a valores numéricos
month_mapping = {
    "Enero": 1, "Febrero": 2, "Marzo": 3, "Abril": 4, "Mayo": 5, "Junio": 6,
    "Julio": 7, "Agosto": 8, "Septiembre": 9, "Octubre": 10, "Noviembre": 11, "Diciembre": 12
}
df["Mes"] = df["Mes"].map(month_mapping)

# Crear columna de fecha
df["Fecha"] = pd.to_datetime(df[["Año", "Mes"]].apply(lambda row: f"{row['Año']}-{row['Mes']:02d}-01", axis=1))

# Agrupar la producción total de energía por mes
df_grouped = df.groupby("Fecha")["Producción Total (GWh)"].sum().reset_index()

# Eliminar valores atípicos
df_grouped = df_grouped[df_grouped["Producción Total (GWh)"] < df_grouped["Producción Total (GWh)"].quantile(0.99)]
results = []

# Entrenamiento del modelo Prophet
df_prophet = df_grouped.rename(columns={"Fecha": "ds", "Producción Total (GWh)": "y"})
train_size = int(len(df_prophet) * 0.8)
train = df_prophet[:train_size]
test = df_prophet[train_size:]

# Lista de valores para cada hiperparámetro
changepoint_prior_scales = [0.01, 0.05, 0.1, 0.5]
seasonality_prior_scales = [0.01, 0.1, 1.0, 10.0]
seasonality_modes = ["additive", "multiplicative"]
n_changepoints_list = [10, 15, 20]

# Generar combinaciones de hiperparámetros
param_grid = list(product(changepoint_prior_scales, seasonality_prior_scales, seasonality_modes, n_changepoints_list))

# Variable para almacenar los mejores resultados
best_mape = float("inf")
best_params = None

# Probar cada combinación
for params in param_grid:
    model = Prophet(
        changepoint_prior_scale=params[0],
        seasonality_prior_scale=params[1],
        seasonality_mode=params[2],
        n_changepoints=params[3]
    )
    
    model.fit(train)
    forecast = model.predict(test)
    
    actual = test["y"].values
    predicted = forecast["yhat"].iloc[-len(actual):].values
    
    # Calcular métricas
    mae = mean_absolute_error(actual, predicted)
    rmse = np.sqrt(mean_squared_error(actual, predicted))
    mape = np.mean(np.abs((actual - predicted) / actual)) * 100
    
    # Guardar en la lista de resultados
    results.append({
        "Changepoint Prior": params[0],
        "Seasonality Prior": params[1],
        "Seasonality Mode": params[2],
        "N Changepoints": params[3],
        "MAE": mae,
        "RMSE": rmse,
        "MAPE (%)": mape
    })
    
    # Calcular MAPE
    mape = np.mean(np.abs((actual - predicted) / actual)) * 100
    
    if mape < best_mape:
        best_mape = mape
        best_params = params

print(f"Mejores hiperparámetros: {best_params}")
print(f"MAPE mínimo obtenido: {best_mape:.2f}%")

# Convertir resultados en DataFrame
df_results = pd.DataFrame(results)

# Ordenar por MAPE (de menor a mayor)
df_results = df_results.sort_values(by="MAPE (%)", ascending=True)

# Mostrar tabla resumen
print("\nTabla Resumen de Métricas:")
print(df_results)

# Guardar en CSV si se necesita
df_results.to_csv("resultados_modelo_prophet.csv", index=False)