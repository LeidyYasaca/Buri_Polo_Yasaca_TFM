import pandas as pd
import matplotlib.pyplot as plt
from prophet import Prophet
from sklearn.metrics import mean_absolute_error, mean_squared_error
import numpy as np

# Carga y preprocesamiento del dataset
file_path = "dataset_consumo.csv"
df = pd.read_csv(file_path)

# Manejar valores nulos
df.dropna(subset=["Mes", "Año", "Energía facturada por servicio electrico (GWh)"], inplace=True)

# Mapear nombres de meses a valores numéricos
month_mapping = {
    "Enero": 1, "Febrero": 2, "Marzo": 3, "Abril": 4, "Mayo": 5, "Junio": 6,
    "Julio": 7, "Agosto": 8, "Septiembre": 9, "Octubre": 10, "Noviembre": 11, "Diciembre": 12
}
df["Mes"] = df["Mes"].map(month_mapping)

# Crear columna de fecha
df["Fecha"] = pd.to_datetime(df[["Año", "Mes"]].apply(lambda row: f"{row['Año']}-{row['Mes']:02d}-01", axis=1))

# Agrupar la producción total de energía por mes
df_grouped = df.groupby("Fecha")["Energía facturada por servicio electrico (GWh)"].sum().reset_index()

# Eliminar valores atípicos
df_grouped = df_grouped[df_grouped["Energía facturada por servicio electrico (GWh)"] < df_grouped["Energía facturada por servicio electrico (GWh)"].quantile(0.99)]

# Entrenamiento del modelo Prophet
df_prophet = df_grouped.rename(columns={"Fecha": "ds", "Energía facturada por servicio electrico (GWh)": "y"})
train_size = int(len(df_prophet) * 0.8)
train = df_prophet[:train_size]
test = df_prophet[train_size:]

# Instanciamos modelo
m = Prophet(
    changepoint_prior_scale= 0.01, seasonality_prior_scale= 0.01, seasonality_mode= 'additive', n_changepoints= 20
)

# Fiteamos el modelo en TRAIN
m.fit(train)

# Predecimos en futuro
forecast = m.predict(test)

# Evaluación del modelo en el conjunto de validación
actual = test["y"].values
predicted = forecast["yhat"].iloc[-len(actual):].values

mae = mean_absolute_error(actual, predicted)
mse = mean_squared_error(actual, predicted)
rmse = np.sqrt(mse)

# Calcular el MAPE
def mean_absolute_percentage_error(y_true, y_pred):
    return np.mean(np.abs((y_true - y_pred) / y_true)) * 100

mape = mean_absolute_percentage_error(actual, predicted)

# Imprimir resultados
print(f"MAE en validación: {mae:.2f}")
print(f"MSE en validación: {mse:.2f}")
print(f"RMSE en validación: {rmse:.2f}")
print(f"MAPE en validación: {mape:.2f}%")

# CARACTERISTICAS DE LA GRAFICA

# 1. Crear la figura y definir su tamaño
plt.figure(figsize=(12, 6))

# 2. Graficar la fase de entrenamiento
plt.plot(train["ds"], train["y"], label="Entrenamiento", color="blue", linestyle="-")

# 3. Graficar la fase de prueba
plt.plot(test["ds"], test["y"], label="Prueba", color="orange", linestyle="-")

# 4. Graficar las predicciones
plt.plot(test["ds"], predicted, label="Predicciones", color="green", linestyle="--")

# 5. Agregar el intervalo de predicción
plt.fill_between(test["ds"], 
                 forecast["yhat_lower"].iloc[-len(test):].values, 
                 forecast["yhat_upper"].iloc[-len(test):].values, 
                 color="green", alpha=0.2, label="Intervalo de predicción")

# 6. Personalizar etiquetas y título
plt.xlabel("Fecha")
plt.ylabel("Energía Facturada(GWh)")
plt.title("Prophet - Predicciones vs. Datos Reales (Consumo)")
plt.legend()

# 7. Mostrar la gráfica

plt.show()