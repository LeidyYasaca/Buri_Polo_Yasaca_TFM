import pandas as pd
import matplotlib.pyplot as plt
from prophet import Prophet
from sklearn.metrics import mean_absolute_error, mean_squared_error
import numpy as np

# Carga y preprocesamiento del dataset
file_path = "dataset_consumo.csv"
df = pd.read_csv(file_path)

# Manejar valores nulos
df.dropna(subset=["Mes", "Año", "Energía facturada por servicio electrico (GWh)"], inplace=True)

# Mapear nombres de meses a valores numéricos
month_mapping = {
    "Enero": 1, "Febrero": 2, "Marzo": 3, "Abril": 4, "Mayo": 5, "Junio": 6,
    "Julio": 7, "Agosto": 8, "Septiembre": 9, "Octubre": 10, "Noviembre": 11, "Diciembre": 12
}
df["Mes"] = df["Mes"].map(month_mapping)

# Crear columna de fecha
df["Fecha"] = pd.to_datetime(df[["Año", "Mes"]].apply(lambda row: f"{row['Año']}-{row['Mes']:02d}-01", axis=1))

# Agrupar la producción total de energía por mes
df_grouped = df.groupby("Fecha")["Energía facturada por servicio electrico (GWh)"].sum().reset_index()

# Eliminar valores atípicos
df_grouped = df_grouped[df_grouped["Energía facturada por servicio electrico (GWh)"] < df_grouped["Energía facturada por servicio electrico (GWh)"].quantile(0.99)]

# Entrenamiento del modelo Prophet
df_prophet = df_grouped.rename(columns={"Fecha": "ds", "Energía facturada por servicio electrico (GWh)": "y"})
train_size = int(len(df_prophet) * 0.8)
train = df_prophet[:train_size]
test = df_prophet[train_size:]

# Instanciamos modelo
m = Prophet(
    changepoint_prior_scale= 0.01, seasonality_prior_scale= 0.01, seasonality_mode= 'additive', n_changepoints= 20
)

# Fiteamos el modelo en TRAIN
m.fit(df_prophet)

# Generar predicciones para 12 meses futuros
future = m.make_future_dataframe(periods=12, freq='M')
forecast = m.predict(future)

# Filtrar solo las predicciones futuras
future_forecast = forecast[forecast["ds"] > df_prophet["ds"].max()]

#### FUTURO 2025 ####

# Ajustar la predicción para que se alinee sin huecos
last_date = df_prophet["ds"].max()
future_forecast = forecast[forecast["ds"] >= last_date]

# Generar una nueva gráfica con los datos reales concatenados con la predicción de 12 meses futuros
plt.figure(figsize=(10, 5))

# Graficar datos históricos
plt.plot(df_prophet["ds"], df_prophet["y"], label="Datos Históricos", color="blue", linestyle="-")

# Graficar la predicción a partir del último dato real
plt.plot(future_forecast["ds"], future_forecast["yhat"], label="Predicciones Futuras", color="orange", linestyle="--")

# Agregar el intervalo de confianza
plt.fill_between(future_forecast["ds"], 
                 future_forecast["yhat_lower"], 
                 future_forecast["yhat_upper"], 
                 color="orange", alpha=0.2, label="Intervalo de predicción")

# Configurar etiquetas y título 
plt.xlabel("Fecha")
plt.ylabel("Energia Facturada (GWh)")
plt.title("Prophet-Predicción de Consumo")
plt.legend()

# Mostrar la gráfica
plt.show()